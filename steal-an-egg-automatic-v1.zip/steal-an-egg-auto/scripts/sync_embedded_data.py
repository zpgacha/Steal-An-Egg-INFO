"""Keep the static site's embedded database in sync with data/game-data.json."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'data/game-data.json').read_text(encoding='utf-8'))
app=root/'app.js'; text=app.read_text(encoding='utf-8')
pattern=r'  const gameData = .*?;\n  const sourceLinks'
replacement='  const gameData = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n  const sourceLinks'
updated,n=re.subn(pattern,replacement,text,count=1,flags=re.S)
if n != 1: raise SystemExit('Could not locate embedded gameData block; refusing to overwrite app.js.')
app.write_text(updated,encoding='utf-8')
