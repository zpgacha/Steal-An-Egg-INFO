#!/usr/bin/env python3
"""Monitor public source pages for changes; do not copy their full content."""
import hashlib, json, re, time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'game-data.json'
STATE = ROOT / 'monitor' / 'source-state.json'
REPORT = ROOT / 'monitor' / 'latest-report.md'

class TextExtractor(HTMLParser):
    SKIP = {'script','style','noscript','svg','nav','footer','header'}
    def __init__(self):
        super().__init__(); self.skip=0; self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP: self.skip += 1
    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip: self.skip -= 1
    def handle_data(self, data):
        if not self.skip:
            t=' '.join(data.split())
            if t: self.parts.append(t)

def fetch(url):
    req=Request(url, headers={'User-Agent':'EggIntelligenceSourceMonitor/1.0 (community reference; contact: website maintainer)'})
    with urlopen(req, timeout=25) as response:
        raw=response.read(4_000_000)
        charset=response.headers.get_content_charset() or 'utf-8'
    html=raw.decode(charset, errors='replace')
    parser=TextExtractor(); parser.feed(html)
    text=' '.join(parser.parts)
    text=re.sub(r'\s+',' ',text).strip()
    return text[:250_000]

def main():
    data=json.loads(DATA.read_text(encoding='utf-8'))
    old=json.loads(STATE.read_text(encoding='utf-8')) if STATE.exists() else {}
    new={}; changes=[]; errors=[]
    for source in data.get('sources', []):
        url=source.get('url','')
        if not url.startswith('https://'): continue
        try:
            text=fetch(url)
            digest=hashlib.sha256(text.encode('utf-8')).hexdigest()
            new[url]={'name':source.get('name',url),'hash':digest,'checked_at':datetime.now(timezone.utc).isoformat(),'excerpt':text[:1200]}
            previous=old.get(url)
            if previous and previous.get('hash') != digest:
                changes.append((source.get('name',url),url,previous.get('excerpt',''),text[:1200]))
            elif not previous:
                changes.append((source.get('name',url),url,'(First successful scan; no previous snapshot.)',text[:1200]))
        except Exception as e:
            errors.append((source.get('name',url),url,str(e)[:220]))
        time.sleep(1.0)
    STATE.write_text(json.dumps(new,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    now=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    data['last_checked']=now
    DATA.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    lines=[f'# Source monitor report — {now}','',
      '> This report detects page changes; a changed page is not automatically proof that game mechanics changed. Review the cited page before treating new claims as facts.','']
    lines += [f'## Changed / newly monitored pages ({len(changes)})','']
    if changes:
        for name,url,before,after in changes:
            lines += [f'### [{name}]({url})','','**Previous snapshot excerpt:**', (before or '(No excerpt saved)')[:1000], '', '**Current snapshot excerpt:**', (after or '(No readable text extracted)')[:1000], '']
    else: lines += ['No text changes detected in successfully checked pages.','']
    lines += [f'## Pages that could not be checked ({len(errors)})','']
    if errors:
        for name,url,err in errors: lines.append(f'- [{name}]({url}) — {err}')
    else: lines.append('All configured source pages were checked successfully.')
    lines += ['', '## Important', '', 'This workflow monitors pages and reports changes. It does **not** blindly rewrite pet-income formulas, speed values, or mutation multipliers based on arbitrary page edits. Many sources are prose-only and may disagree; those changes need structured extraction and validation before being published as game data.']
    REPORT.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Monitored {len(new)} pages; {len(changes)} changed/new; {len(errors)} failed.')
if __name__=='__main__': main()
