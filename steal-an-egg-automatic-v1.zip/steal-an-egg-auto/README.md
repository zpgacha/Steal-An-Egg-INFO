# Egg Intelligence — Automated Source Monitor Edition

A dark-themed Steal an Egg fan reference website with a daily source-monitoring workflow. It keeps the source links visible in the website and checks those source pages for text changes.

## What runs automatically

Once this project is uploaded to a GitHub repository and GitHub Actions is enabled, `.github/workflows/daily-source-check.yml` runs once daily (and can be run manually from the Actions tab). It:

1. Checks the source URLs in `data/game-data.json`.
2. Compares readable page text with the previous scan.
3. Writes `monitor/latest-report.md` with changed-page excerpts and failed checks.
4. Updates the `last_checked` date and syncs the website's embedded data bundle.
5. Commits changes to the repository automatically.

The website's existing calculators and reference pages remain included.

## Important honesty note

This is automatic **source monitoring**, not a guarantee that every new game fact will be automatically discovered and safely published. Sources may block bots, change layout, or contradict each other. The monitor reports page changes, but does not blindly change pet-income formulas, mutation multipliers, or speed values from arbitrary prose. Automatically publishing factual game data requires a reliable structured feed or an AI extraction/validation service (which needs a provider API key and can incur costs). The current workflow does not require a paid API key.

## Put it online and enable daily checks

1. Create a GitHub account if needed.
2. Create a new repository, e.g. `egg-intelligence`.
3. Upload the **contents** of this folder to the repository (not just the ZIP).
4. Open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Open the **Actions** tab and enable workflows if GitHub asks.
6. Open **Actions → Daily source check → Run workflow** for the first manual scan. It will then run daily automatically.
7. Your live website URL will be shown under **Settings → Pages**.

If GitHub Pages does not appear immediately, wait a minute or two and refresh Settings → Pages.

## Review source changes

Open `monitor/latest-report.md` in the repository after a run. It shows pages whose readable text changed and small excerpts for comparison. A page changing does not necessarily mean its game facts changed.

## Edit source list

Edit `data/game-data.json` and add an object to `sources`, e.g.:

```json
{
  "name": "New community guide",
  "url": "https://example.com/guide",
  "usedFor": "What this source helps verify"
}
```

Use only sources you are allowed to access, and retain attribution links in the site footer.

## Run the checker locally (optional)

Python 3.12+; no third-party packages required:

```bash
python scripts/monitor_sources.py
python scripts/sync_embedded_data.py
```

## Limitations

- Checks public HTTPS pages with readable HTML text; it cannot see private Discord messages or content behind logins.
- Some sites block automated requests. Those failures are listed in the report.
- A change-detection system cannot guarantee it detects every update, especially pages that render content with JavaScript.
- This is an unofficial fan-made reference and is not affiliated with the game developers.
