(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const ids = ["start-speed", "end-speed", "elapsed", "current-speed", "target-speed", "duration-hours"];
  const form = $("calculator-form");
  const error = $("error-message");

  // Inputs and displayed speeds are in billions. Calculations use unrounded
  // JavaScript numbers; formatting is applied only to the output.
  function numberFrom(id, optional = false) {
    const raw = $(id).value.trim();
    if (optional && raw === "") return null;
    if (raw === "" || !Number.isFinite(Number(raw))) throw new Error("Please enter valid numbers in the required fields.");
    return Number(raw);
  }

  function fmt(value, maxFractionDigits = 4) {
    if (!Number.isFinite(value)) return "—";
    const abs = Math.abs(value);
    if (abs !== 0 && (abs >= 1e6 || abs < 0.0001)) {
      return value.toExponential(4).replace(/\.?0+e/, "e");
    }
    return new Intl.NumberFormat("en-US", {
      maximumFractionDigits: maxFractionDigits,
      minimumFractionDigits: 0
    }).format(value);
  }

  function fmtBillions(billions) {
    const abs = Math.abs(billions);
    if (abs >= 1e6) return `${fmt(billions / 1e6)} quadrillion`;
    if (abs >= 1e3) return `${fmt(billions / 1e3)} trillion`;
    if (abs > 0 && abs < 1) return `${fmt(billions * 1000)} million`;
    return `${fmt(billions)} billion`;
  }

  function fmtDuration(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return "—";
    if (seconds === 0) return "0 seconds";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const parts = [];
    if (days) parts.push(`${days}d`);
    if (hours) parts.push(`${hours}h`);
    if (minutes) parts.push(`${minutes}m`);
    if (secs || parts.length === 0) parts.push(`${secs}s`);
    return parts.slice(0, 3).join(" ");
  }

  function calculate() {
    error.textContent = "";
    try {
      const start = numberFrom("start-speed");
      const end = numberFrom("end-speed");
      const elapsed = numberFrom("elapsed");
      const current = numberFrom("current-speed", true);
      const target = numberFrom("target-speed", true);
      const durationHours = numberFrom("duration-hours");

      if (elapsed <= 0) throw new Error("Elapsed time must be greater than zero.");
      if (durationHours < 0) throw new Error("Projection duration cannot be negative.");
      if (end < start) throw new Error("Ending speed is lower than starting speed. Check the readings or enter a different measurement.");
      if (current !== null && current < 0) throw new Error("Current speed cannot be negative.");
      if (target !== null && target < 0) throw new Error("Target speed cannot be negative.");

      const gainBillions = end - start;
      const rateBillionsPerSecond = gainBillions / elapsed;
      const projectedBillions = rateBillionsPerSecond * durationHours * 3600;
      const dayBillions = rateBillionsPerSecond * 86400;

      $("rate-per-second").textContent = `${fmtBillions(rateBillionsPerSecond)} / sec`;
      $("rate-per-minute").textContent = fmtBillions(rateBillionsPerSecond * 60);
      $("rate-per-five").textContent = fmtBillions(rateBillionsPerSecond * 300);
      $("rate-per-hour").textContent = fmtBillions(rateBillionsPerSecond * 3600);
      $("projection-title").textContent = `${fmt(durationHours, 2)}-hour estimate`;
      $("projected-gain").textContent = fmtBillions(projectedBillions);
      $("projected-day").textContent = fmtBillions(dayBillions);

      if (current === null || target === null) {
        $("time-to-target").textContent = "Add current and target speed";
        $("target-note").textContent = "Enter both optional fields to calculate the estimated time to your goal.";
      } else if (target <= current) {
        $("time-to-target").textContent = "Target already reached";
        $("target-note").textContent = `Current speed is ${fmtBillions(current)}; target is ${fmtBillions(target)}.`;
      } else if (rateBillionsPerSecond <= 0) {
        $("time-to-target").textContent = "No positive gain measured";
        $("target-note").textContent = "Record a test with a positive speed increase to estimate time to target.";
      } else {
        const seconds = (target - current) / rateBillionsPerSecond;
        $("time-to-target").textContent = fmtDuration(seconds);
        $("target-note").textContent = `Need ${fmtBillions(target - current)} more at the measured rate. Estimate assumes the rate stays constant.`;
      }
    } catch (e) {
      error.textContent = e.message || "Something went wrong. Check your inputs.";
    }
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    calculate();
  });

  ids.forEach((id) => $(id).addEventListener("input", calculate));

  $("reset-button").addEventListener("click", () => {
    $("start-speed").value = "";
    $("end-speed").value = "";
    $("elapsed").value = "";
    $("current-speed").value = "";
    $("target-speed").value = "";
    $("duration-hours").value = "8";
    error.textContent = "";
    $("rate-per-second").textContent = "—";
    $("rate-per-minute").textContent = "—";
    $("rate-per-five").textContent = "—";
    $("rate-per-hour").textContent = "—";
    $("projected-gain").textContent = "—";
    $("projected-day").textContent = "—";
    $("time-to-target").textContent = "Add current and target speed";
    $("target-note").textContent = "Uses the measured rate above. Target and current speed are in billions.";
  });

  const views = {
    speed: { el: $("speed-view"), title: "Speed calculator" },
    income: { el: $("income-view"), title: "Pet income calculator" },
    database: { el: $("database-view"), title: "Game database" },
    assistant: { el: $("assistant-view"), title: "AI assistant" }
  };
  document.querySelectorAll(".nav-item").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.view;
      document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b === button));
      Object.entries(views).forEach(([name, view]) => view.el.classList.toggle("hidden", name !== key));
      $("page-title").textContent = views[key].title;
    });
  });


  // Embedded reference data keeps the site usable when opened directly from index.html.
  const gameData = {"game":"Steal an Egg","status":"community-reference","last_checked":"2026-10-12","notes":"Community-guide summaries, not official developer data. Values can change after updates; where sources disagree, verify in-game.","biomes":[{"name":"Forest","speed":"No gate listed","guardian":"Chicken","eggs":"Chicken, Dog, Bird, Burrowing Owl, Raccoon, Bear, Fox and more"},{"name":"Lake","speed":"900","guardian":"Swan","eggs":"See linked egg guide"},{"name":"Desert","speed":"10,000 (10K)","guardian":"Scorpion","eggs":"See linked egg guide"},{"name":"Jungle","speed":"40,000 (40K)","guardian":"Tiger","eggs":"See linked egg guide"},{"name":"Snow","speed":"170,000 (170K)","guardian":"Yeti","eggs":"See linked egg guide"},{"name":"Volcano","speed":"700,000 (700K)","guardian":"Hellhound / Cerberus (source wording differs)","eggs":"See linked egg guide"},{"name":"Abyss Ocean","speed":"2,500,000 (2.5M)","guardian":"Moby / Beluga Whale (source wording differs)","eggs":"See linked egg guide"},{"name":"Prehistoric","speed":"17M–18M (sources disagree)","guardian":"T-Rex","eggs":"See linked egg guide"},{"name":"Cosmic","speed":"700,000,000 (700M)","guardian":"Dragon / Cosmic Skeleton Boss (source wording differs)","eggs":"See linked egg guide"},{"name":"Cherry Blossom","speed":"About 2.5B reported; verify in-game","guardian":"Oni Tiger / Sakura guardian (source wording differs)","eggs":"Crane, Salamander, Red Panda, Koi, Snowy Owl, Stag, Oni Tiger, Kitsune"},{"name":"Titan Temple","speed":"About 7B reported; verify in-game","guardian":"Gorilla King","eggs":"Crustacia, Spideron, Bladehide, Mantaris, Rhinotaur, Mutant Shark, Gorilla King, Nightflame"},{"name":"Angels & Demons","speed":"Not confirmed in this dataset","guardian":"Not confirmed in this dataset","eggs":"Light-side and dark-side egg sets; check latest guide"},{"name":"Enchanted Forest","speed":"50B reported by Eldorado; verify in-game","guardian":"Not confirmed in this dataset","eggs":"Prism Gecko, Petal Beetle, Enchanted Bluejay, Astral Jackalope, Spirit Panda, Starry Fox, Celestial Sunlion, Royal Skywhale"}],"eggMechanics":[{"topic":"Standard egg reset cycle","summary":"Eldorado describes a 5-minute cycle: about 4 minutes 50 seconds of collection followed by a 10-second night/reset period."},{"topic":"Night growth boost","summary":"Eldorado reports eggs grow 30× faster during the 10-second night/reset window. Verify current behavior in-game before relying on it."},{"topic":"Rare egg spawns","summary":"Secret, Eternal and Divine eggs are described as random rather than guaranteed every reset; server-wide notices may identify their spawn."},{"topic":"Hatch times","summary":"Reported hatch time varies with egg size/weight, rarity, mutation and active boosts; listed times are not universal guarantees."},{"topic":"Egg colors and income","summary":"A community guide reports that color changes appearance rather than income; treat as community-reported and verify if important."},{"topic":"Limited/event/shop eggs","summary":"Some eggs are tied to events or the premium shop rather than ordinary biome nests. Availability can change with updates."}],"sampleEggs":[{"biome":"Forest","egg":"Chicken egg","hatch":"10 sec","rarity":"Common"},{"biome":"Forest","egg":"Dog egg","hatch":"15 sec","rarity":"Common"},{"biome":"Forest","egg":"Bird egg","hatch":"25 sec","rarity":"Uncommon"},{"biome":"Forest","egg":"Burrowing Owl egg","hatch":"40 sec","rarity":"Rare"},{"biome":"Forest","egg":"Raccoon egg","hatch":"50 sec","rarity":"Rare"},{"biome":"Forest","egg":"Bear egg","hatch":"1 min 30 sec","rarity":"Epic"},{"biome":"Forest","egg":"Fox egg","hatch":"2 min","rarity":"Epic"},{"biome":"Cosmic","egg":"Centapede egg","hatch":"2 min","rarity":"Epic"},{"biome":"Cosmic","egg":"Cosmic Gecko egg","hatch":"4 min","rarity":"Legendary"},{"biome":"Cosmic","egg":"Cosmic Gorilla egg","hatch":"7 min","rarity":"Mythic"},{"biome":"Cosmic","egg":"La Vacca Saturno Saturnita egg","hatch":"13 min","rarity":"Cosmic"},{"biome":"Cosmic","egg":"Cosmic Dragon egg","hatch":"3 hours","rarity":"Secret"},{"biome":"Cosmic","egg":"Cosmic Skeleton Boss egg","hatch":"2 hours 30 min","rarity":"Secret"},{"biome":"Cosmic","egg":"Eternal Lunar Dragon egg","hatch":"7 hours","rarity":"Eternal"},{"biome":"Cosmic","egg":"Unicorn egg","hatch":"12 hours","rarity":"Divine"},{"biome":"Cherry Blossom","egg":"Crane egg","hatch":"3 min","rarity":"Epic"},{"biome":"Cherry Blossom","egg":"Salamander egg","hatch":"5 min","rarity":"Legendary"},{"biome":"Cherry Blossom","egg":"Red Panda egg","hatch":"8 min","rarity":"Mythic"},{"biome":"Cherry Blossom","egg":"Koi egg","hatch":"25 min","rarity":"Cosmic"},{"biome":"Cherry Blossom","egg":"Snowy Owl egg","hatch":"15 min","rarity":"Cosmic"},{"biome":"Cherry Blossom","egg":"Stag egg","hatch":"3 hours","rarity":"Secret"},{"biome":"Cherry Blossom","egg":"Oni Tiger egg","hatch":"8 hours","rarity":"Eternal"},{"biome":"Cherry Blossom","egg":"Kitsune egg","hatch":"14 hours","rarity":"Divine"},{"biome":"Titan Temple","egg":"Crustacia egg","hatch":"4 min","rarity":"Legendary"},{"biome":"Titan Temple","egg":"Spideron egg","hatch":"6 min","rarity":"Legendary"},{"biome":"Titan Temple","egg":"Bladehide egg","hatch":"9 min","rarity":"Mythic"},{"biome":"Titan Temple","egg":"Mantaris egg","hatch":"17 min","rarity":"Cosmic"},{"biome":"Titan Temple","egg":"Rhinotaur egg","hatch":"29 min","rarity":"Cosmic"},{"biome":"Titan Temple","egg":"Mutant Shark egg","hatch":"3 hours","rarity":"Secret"},{"biome":"Titan Temple","egg":"Gorilla King egg","hatch":"9 hours","rarity":"Eternal"},{"biome":"Titan Temple","egg":"Nightflame egg","hatch":"16 hours","rarity":"Divine"}],"sources":[{"name":"Steal An Egg Wiki (Fandom)","url":"https://stealanegg.fandom.com/wiki/Steal_An_Egg_Wiki","usedFor":"Community reference / game overview"},{"name":"IGN — All Biomes","url":"https://www.ign.com/wikis/steal-an-egg-roblox/All_Biomes","usedFor":"Biome progression and guide context"},{"name":"IGN — Steal an Egg guide hub","url":"https://www.ign.com/wikis/steal-an-egg-roblox","usedFor":"General guide context"},{"name":"Eldorado.gg — Eggs list","url":"https://www.eldorado.gg/blog/steal-an-egg/steal-an-egg-eggs-list/","usedFor":"Example egg names, rarity, hatch times and reported reset mechanics"},{"name":"StealAnEgg.app","url":"https://stealanegg.app/","usedFor":"Game reference and calculator; used to cross-check concepts, not to copy its tool or data wholesale"},{"name":"GameBoost — Mutations & Sizes","url":"https://gameboost.com/blog/steal-an-egg-mutation-sizes","usedFor":"Community-reported mutation multipliers, acquisition paths and size context"},{"name":"wikiHow — All Egg List","url":"https://www.wikihow.com/Steal-an-Egg-All-Egg-List","usedFor":"Additional egg-list reference"},{"name":"Steal An Egg Wiki — Mutations","url":"https://stealanegg.fandom.com/wiki/Mutations","usedFor":"Community mutation notes; values may conflict with other guides"},{"name":"TechWiser — Enchanted Forest","url":"https://techwiser.com/steal-an-egg-enchanted-forest-biome-guide/","usedFor":"Enchanted Forest guide and reported update context"},{"name":"StealAnEgg.app — Income Calculator","url":"https://stealanegg.app/tools/income-calculator/","usedFor":"Example of a measurement-led income calculator; formulas not copied"},{"name":"GrindMath — Steal an Egg Calculator","url":"https://grindmath.app/steal-an-egg/","usedFor":"Additional community calculator and formula comparison"},{"name":"STEAL EGG — Mutations Guide","url":"https://stealegg.com/en/guides/mutations-guide/","usedFor":"Alternative mutation and weight-curve reference; compare values before relying on them"}],"mutations":[{"name":"Silver","multiplier":"1.25×","bonus":0.25,"confidence":"Community-reported; sources disagree","notes":"Reported natural mutation."},{"name":"Golden","multiplier":"2×","bonus":1.0,"confidence":"Community-reported; sources disagree","notes":"Reported natural mutation."},{"name":"Rainbow","multiplier":"2.5×","bonus":1.5,"confidence":"Community-reported; sources disagree","notes":"Reported natural mutation; some newer community sources list a different value."},{"name":"Bloom","multiplier":"1.5×","bonus":0.5,"confidence":"Community-reported; sources disagree","notes":"Associated with Sakura Incubator in guides."},{"name":"Spirit Bloom","multiplier":"3×","bonus":2.0,"confidence":"Community-reported; sources disagree","notes":"Associated with Sakura Incubator in guides."},{"name":"Parasite","multiplier":"3×","bonus":2.0,"confidence":"Community-reported; sources disagree","notes":"Event/reward path varies by guide and update."},{"name":"Fractured","multiplier":"2.75×","bonus":1.75,"confidence":"Community-reported; sources disagree","notes":"Reported boss-related mutation."}],"sizeFormula":{"description":"One community guide reports a diminishing-returns curve based on pet weight divided by the same species’ reference weight. It is not confirmed as an official developer formula.","formula":"For ratio r = weight/reference weight: if r <= 125, size factor = r^(37/60); if r > 125, size factor = 19.637875755794113 * ((r^(1/3))/5)^1.2","source":"https://stealegg.com/en/guides/mutations-guide/","status":"Community-reported; compare against in-game results."}};
  const sourceLinks = gameData.sources.map(source => `<a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">${esc(source.name)}</a>`);

  function renderDatabase() {
    if (!dbContent) return;
    const q = (dbSearch.value || "").trim().toLowerCase();
    let html = "";
    if (activeDbTab === "biomes") {
      const rows = gameData.biomes.filter(x => Object.values(x).join(" ").toLowerCase().includes(q));
      html = rows.length ? `<div class="db-table-wrap"><table class="db-table"><thead><tr><th>Biome</th><th>Reported speed gate</th><th>Guardian</th><th>Egg reference</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.speed)}</td><td>${esc(x.guardian)}</td><td>${esc(x.eggs)}</td></tr>`).join("")}</tbody></table></div>` : `<div class="db-empty">No matching biomes.</div>`;
    } else if (activeDbTab === "eggs") {
      const rows = gameData.sampleEggs.filter(x => Object.values(x).join(" ").toLowerCase().includes(q));
      html = rows.length ? `<div class="db-table-wrap"><table class="db-table"><thead><tr><th>Egg</th><th>Biome / source grouping</th><th>Reported hatch time</th><th>Rarity</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.egg)}</td><td>${esc(x.biome)}</td><td>${esc(x.hatch)}</td><td><span class="db-pill">${esc(x.rarity)}</span></td></tr>`).join("")}</tbody></table></div><p class="database-caveat">This is a starter subset of the published egg guide, not a complete item dump. Hatch times are reported examples and can vary with size, weight, mutations, and boosts. See the linked Eldorado guide for its current expanded list.</p>` : `<div class="db-empty">No matching eggs in this starter subset.</div>`;
    } else if (activeDbTab === "mechanics") {
      const rows = gameData.eggMechanics.filter(x => (x.topic+" "+x.summary).toLowerCase().includes(q));
      html = rows.length ? `<div class="db-list">${rows.map(x=>`<article class="db-info-row"><strong>${esc(x.topic)}</strong><p>${esc(x.summary)}</p></article>`).join("")}</div>` : `<div class="db-empty">No matching mechanics notes.</div>`;
    } else if (activeDbTab === "mutations") {
      const rows = (gameData.mutations || []).filter(x => (x.name+" "+x.multiplier+" "+x.confidence+" "+x.notes).toLowerCase().includes(q));
      html = rows.length ? `<div class="db-table-wrap"><table class="db-table"><thead><tr><th>Mutation</th><th>Reported multiplier</th><th>Confidence</th><th>Notes</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.multiplier)}</td><td>${esc(x.confidence)}</td><td>${esc(x.notes)}</td></tr>`).join("")}</tbody></table></div><article class="db-info-row"><strong>Reported size curve</strong><p>${esc(gameData.sizeFormula.description)} Formula: ${esc(gameData.sizeFormula.formula)}</p><p>Source: <a href="${esc(gameData.sizeFormula.source)}" target="_blank" rel="noopener noreferrer">${esc(gameData.sizeFormula.source)}</a></p></article>` : `<div class="db-empty">No matching mutations.</div>`;
    } else {
      const rows = gameData.sources.filter(x => (x.name+" "+x.usedFor+" "+x.url).toLowerCase().includes(q));
      html = rows.length ? `<div class="db-list">${rows.map(x=>`<article class="db-info-row db-source"><strong><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${esc(x.name)}</a></strong><p>${esc(x.usedFor)}</p><small>${esc(x.url)}</small></article>`).join("")}</div><p class="database-caveat">This project summarizes facts in its own words and links back to the original guides. It does not reproduce the articles or their images.</p>` : `<div class="db-empty">No matching sources.</div>`;
    }
    dbContent.innerHTML = html;
  }

  document.querySelectorAll(".db-tab").forEach(button => {
    button.addEventListener("click", () => {
      activeDbTab = button.dataset.dbTab;
      document.querySelectorAll(".db-tab").forEach(b => b.classList.toggle("active", b === button));
      renderDatabase();
    });
  });
  if (dbSearch) dbSearch.addEventListener("input", renderDatabase);

  // Pet income estimator: community-reported diminishing size curve plus additive mutation bonuses.
  const incomeForm = $("income-form");
  const incomeError = $("income-error");
  const moneyFmt = (n) => {
    if (!Number.isFinite(n)) return "—";
    const abs = Math.abs(n);
    const units = [[1e12,"T"],[1e9,"B"],[1e6,"M"],[1e3,"K"]];
    for (const [unit, suffix] of units) if (abs >= unit) return "$"+(n/unit).toLocaleString("en-US",{maximumFractionDigits:3})+suffix;
    return "$"+n.toLocaleString("en-US",{maximumFractionDigits:3});
  };
  function calculateIncome() {
    if (!incomeForm) return;
    incomeError.textContent = "";
    const base = Number($("base-income").value);
    const weightRaw = $("pet-weight").value.trim();
    const refRaw = $("reference-weight").value.trim();
    const boost = Number($("money-boost").value || 1);
    if ($("base-income").value.trim() === "" || !Number.isFinite(base) || base < 0) { incomeError.textContent = "Enter a valid base income per second."; return; }
    if (!Number.isFinite(boost) || boost < 0) { incomeError.textContent = "Other money multiplier must be zero or greater."; return; }
    let sizeFactor = 1;
    if (weightRaw !== "" || refRaw !== "") {
      const weight = Number(weightRaw), ref = Number(refRaw);
      if (weightRaw === "" || refRaw === "" || !Number.isFinite(weight) || !Number.isFinite(ref) || weight <= 0 || ref <= 0) { incomeError.textContent = "Enter both weight values above zero, or leave both blank to ignore size."; return; }
      const ratio = weight / ref;
      sizeFactor = ratio <= 125 ? Math.pow(ratio, 37/60) : 19.637875755794113 * (Math.pow(ratio, 1/3)/5)**1.2;
    }
    const mutationValues = {"Silver":1.2,"Bloom":1.25,"Spirit Bloom":2.5,"Golden":2.5,"Fractured":2.75,"Scrambled":2.75,"Nitro":2.75,"Enchanted":2.85,"Parasite":3,"Rainbow":3.5};
    const selected = [...incomeForm.querySelectorAll('input[name="mutation"]:checked')].map(x=>x.value);
    const mutationFactor = 1 + selected.reduce((sum,name)=>sum + ((mutationValues[name] || 1)-1),0);
    const result = base * sizeFactor * mutationFactor * boost;
    $("income-second").textContent = moneyFmt(result);
    $("income-minute").textContent = moneyFmt(result*60);
    $("income-hour").textContent = moneyFmt(result*3600);
    $("income-day").textContent = moneyFmt(result*86400);
    $("size-factor").textContent = "×"+sizeFactor.toLocaleString("en-US",{maximumFractionDigits:4});
    $("mutation-factor").textContent = "×"+mutationFactor.toLocaleString("en-US",{maximumFractionDigits:4});
    $("boost-factor").textContent = "×"+boost.toLocaleString("en-US",{maximumFractionDigits:4});
    $("income-formula").textContent = `${moneyFmt(base)} base × ${sizeFactor.toFixed(4)} size × ${mutationFactor.toFixed(4)} mutation × ${boost.toFixed(4)} other boost. Mutation stacking rule: 1 + sum(each multiplier − 1). Selected mutations: ${selected.length ? selected.join(", ") : "none"}.`;
  }
  if (incomeForm) {
    incomeForm.addEventListener("submit", e => { e.preventDefault(); calculateIncome(); });
    incomeForm.querySelectorAll("input").forEach(input => input.addEventListener("input", calculateIncome));
    $("income-reset").addEventListener("click", () => { incomeForm.reset(); $("money-boost").value="1"; ["income-second","income-minute","income-hour","income-day","size-factor","mutation-factor","boost-factor"].forEach(id=>$(id).textContent="—"); $("income-formula").textContent="Enter a base income to see an estimate."; incomeError.textContent=""; });
  }
  renderDatabase();

  calculate();
})();
